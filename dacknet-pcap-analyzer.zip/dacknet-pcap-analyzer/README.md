# DackNet-Ops PCAP Analyzer

A password-protected desktop tool for interpreting network traffic
captured from Wireshark. Upload a `.pcap` / `.pcapng` file and get a
readable breakdown of protocols, top talkers, conversations, ports,
DNS lookups, and a few basic red-flag heuristics (possible port
scans, ARP spoofing, one-host-dominates-traffic).

![DackNet-Ops](assets/logo.png)

## Features

- 🔒 Password-gated login screen (SHA-256 checked, not stored in plain text)
- 📂 Upload any Wireshark-saved capture file
- 📊 Protocol breakdown, top talkers, top conversations, top ports, top DNS queries
- ⚠️ Basic heuristics that flag traffic worth a closer look
- 🧵 Runs analysis on a background thread so the UI never freezes
- 🎨 DackNet-Ops neon-green-on-black theme throughout

## Getting Started

### 1. Clone the repository

```bash
git clone https://github.com/<your-username>/dacknet-pcap-analyzer.git
cd dacknet-pcap-analyzer
```

### 2. Install dependencies

It's recommended to use a virtual environment:

```bash
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 3. Run the program

```bash
python main.py
```

You'll be asked for the access password before the dashboard opens.

## Project Structure

```
dacknet-pcap-analyzer/
├── main.py                # Entry point — run this
├── core/
│   ├── auth.py             # Password-hash login check
│   └── pcap_engine.py      # Parses the capture file, builds the report
├── gui/
│   └── app.py               # Login screen + dashboard (CustomTkinter)
├── assets/
│   └── logo.png              # DackNet-Ops logo shown in the app
├── requirements.txt
└── README.md
```

## Changing the Password

The login password is not stored as plain text — only its SHA-256
hash is kept in `core/auth.py`. To change it:

```python
import hashlib
print(hashlib.sha256("your-new-password".encode()).hexdigest())
```

Paste the printed hash into `CORRECT_PASSWORD_HASH` in `core/auth.py`.

## Notes

- The "suspicious activity" warnings are lightweight heuristics meant
  to point a human analyst toward interesting packets — they are
  **not** a replacement for a real IDS/IPS or for reviewing the
  capture directly in Wireshark.
- Large capture files are streamed packet-by-packet rather than
  loaded fully into memory, so multi-gigabyte captures should still
  work, just more slowly.
