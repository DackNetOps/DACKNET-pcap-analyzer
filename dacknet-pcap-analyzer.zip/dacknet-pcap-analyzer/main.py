"""
main.py
-------------------------------------------------------------------
DackNet-Ops PCAP Analyzer — Entry Point
-------------------------------------------------------------------
Run this file to start the application:

    python main.py

It just wires the pieces together: build the app window (which
starts on the login screen) and hand control over to Tkinter's
main event loop.
-------------------------------------------------------------------
"""

from gui.app import DackNetPcapApp


def main():
    app = DackNetPcapApp()
    app.mainloop()


if __name__ == "__main__":
    main()
