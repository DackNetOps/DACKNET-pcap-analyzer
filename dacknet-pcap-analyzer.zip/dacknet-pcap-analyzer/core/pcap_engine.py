"""
core/pcap_engine.py
-------------------------------------------------------------------
DackNet-Ops PCAP Analyzer — Packet Parsing & Analysis Engine
-------------------------------------------------------------------
This module does the actual "interpreting" of a Wireshark capture
file (.pcap or .pcapng). It does NOT touch the GUI at all — it just
takes a file path in and returns a Python dictionary full of
statistics out. Keeping it separate from the GUI means:
    1. It's easier to test on its own.
    2. It's easier to re-use (e.g. from a command-line script).
    3. The GUI code stays focused on drawing widgets, not parsing.

WHAT LIBRARY DOES THE PARSING?
    We use Scapy (https://scapy.net/). It is a pure-Python packet
    manipulation library, so it does NOT require Wireshark or tshark
    to be installed on the machine — only `pip install scapy`.
    Scapy can read any file Wireshark can save (.pcap / .pcapng).
-------------------------------------------------------------------
"""

from collections import Counter, defaultdict
from scapy.all import PcapReader, IP, IPv6, TCP, UDP, ICMP, ARP, DNS, DNSQR, Ether


# Well-known ports we'll label nicely in the report instead of
# just showing a bare number.
COMMON_PORTS = {
    20: "FTP-DATA", 21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP",
    53: "DNS", 67: "DHCP", 68: "DHCP", 80: "HTTP", 110: "POP3",
    123: "NTP", 143: "IMAP", 161: "SNMP", 443: "HTTPS", 445: "SMB",
    3306: "MySQL", 3389: "RDP", 8080: "HTTP-ALT",
}


def _label_port(port: int) -> str:
    """Return a human-friendly label for a port number, e.g. '443 (HTTPS)'."""
    name = COMMON_PORTS.get(port)
    return f"{port} ({name})" if name else str(port)


class PcapAnalyzer:
    """
    Reads a capture file once, streaming packet-by-packet (so even
    large captures don't need to fully load into memory), and builds
    up statistics as it goes.
    """

    def __init__(self, filepath: str):
        self.filepath = filepath

        # ---- Running counters, filled in during analyze() ----
        self.total_packets = 0
        self.total_bytes = 0
        self.first_timestamp = None
        self.last_timestamp = None

        self.protocol_counts = Counter()          # e.g. {"TCP": 120, "UDP": 40}
        self.src_ip_counts = Counter()             # packets sent BY each IP
        self.dst_ip_counts = Counter()             # packets sent TO each IP
        self.src_ip_bytes = Counter()               # bytes sent BY each IP
        self.conversation_counts = Counter()        # {(src, dst): count}
        self.dst_port_counts = Counter()             # popularity of destination ports
        self.dns_queries = Counter()                  # domain names looked up

        # For very basic port-scan detection: for each source IP,
        # which distinct destination ports did it try to reach?
        self._scan_tracker = defaultdict(set)

        # For very basic ARP-spoof detection: which MAC address(es)
        # have claimed to own each IP address?
        self._arp_ip_to_macs = defaultdict(set)

        self.warnings = []   # human-readable heads-up notes we generate

    # -----------------------------------------------------------
    # MAIN ENTRY POINT
    # -----------------------------------------------------------
    def analyze(self, progress_callback=None):
        """
        Stream through every packet in the capture file and update
        all the counters above.

        Args:
            progress_callback: optional function(int) called every
                so often with the number of packets processed so far,
                so the GUI can update a progress bar without us
                needing to know anything about GUI widgets.
        """
        with PcapReader(self.filepath) as reader:
            for packet in reader:
                self._process_packet(packet)
                self.total_packets += 1

                if progress_callback and self.total_packets % 200 == 0:
                    progress_callback(self.total_packets)

        self._run_heuristics()
        return self.build_report()

    # -----------------------------------------------------------
    # PER-PACKET PROCESSING
    # -----------------------------------------------------------
    def _process_packet(self, packet):
        # Track capture time span.
        ts = float(packet.time)
        if self.first_timestamp is None:
            self.first_timestamp = ts
        self.last_timestamp = ts

        size = len(packet)
        self.total_bytes += size

        # --- Layer 3: IP addressing ---
        ip_layer = None
        if packet.haslayer(IP):
            ip_layer = packet[IP]
        elif packet.haslayer(IPv6):
            ip_layer = packet[IPv6]

        if ip_layer is not None:
            src, dst = ip_layer.src, ip_layer.dst
            self.src_ip_counts[src] += 1
            self.dst_ip_counts[dst] += 1
            self.src_ip_bytes[src] += size
            self.conversation_counts[(src, dst)] += 1

        # --- Layer 4: protocol + ports ---
        if packet.haslayer(TCP):
            self.protocol_counts["TCP"] += 1
            dport = packet[TCP].dport
            self.dst_port_counts[dport] += 1
            if ip_layer is not None:
                self._scan_tracker[ip_layer.src].add(dport)
        elif packet.haslayer(UDP):
            self.protocol_counts["UDP"] += 1
            dport = packet[UDP].dport
            self.dst_port_counts[dport] += 1
            if ip_layer is not None:
                self._scan_tracker[ip_layer.src].add(dport)
        elif packet.haslayer(ICMP):
            self.protocol_counts["ICMP"] += 1
        elif packet.haslayer(ARP):
            self.protocol_counts["ARP"] += 1
            arp = packet[ARP]
            if arp.op == 2:  # "is-at" (ARP reply) — a MAC claiming an IP
                self._arp_ip_to_macs[arp.psrc].add(arp.hwsrc)
        else:
            self.protocol_counts["Other"] += 1

        # --- Application layer: DNS queries ---
        if packet.haslayer(DNS) and packet.haslayer(DNSQR):
            try:
                qname = packet[DNSQR].qname.decode(errors="ignore").rstrip(".")
                if qname:
                    self.dns_queries[qname] += 1
            except Exception:
                pass  # malformed DNS record — skip rather than crash

    # -----------------------------------------------------------
    # SIMPLE SECURITY HEURISTICS
    # -----------------------------------------------------------
    def _run_heuristics(self):
        """
        Very lightweight, rule-of-thumb checks — NOT a substitute for
        a real IDS. They exist to point a human analyst toward
        traffic worth a closer look in Wireshark itself.
        """
        # Possible port scan: one source IP touching many distinct ports.
        for src, ports in self._scan_tracker.items():
            if len(ports) >= 15:
                self.warnings.append(
                    f"Possible port scan: {src} contacted {len(ports)} "
                    f"distinct ports."
                )

        # Possible ARP spoofing: one IP address claimed by 2+ MAC addresses.
        for ip, macs in self._arp_ip_to_macs.items():
            if len(macs) >= 2:
                mac_list = ", ".join(macs)
                self.warnings.append(
                    f"Possible ARP spoofing: IP {ip} was claimed by "
                    f"{len(macs)} different MAC addresses ({mac_list})."
                )

        # Chatty talkers: flag if one source IP is >40% of all traffic.
        if self.total_packets > 0:
            top_src, top_count = (
                self.src_ip_counts.most_common(1)[0]
                if self.src_ip_counts else (None, 0)
            )
            if top_src and top_count / self.total_packets > 0.4:
                pct = round(100 * top_count / self.total_packets, 1)
                self.warnings.append(
                    f"{top_src} generated {pct}% of all captured traffic — "
                    f"worth a closer look."
                )

    # -----------------------------------------------------------
    # FINAL REPORT
    # -----------------------------------------------------------
    def build_report(self) -> dict:
        """Package everything collected into one plain dictionary."""
        duration = None
        if self.first_timestamp is not None and self.last_timestamp is not None:
            duration = round(self.last_timestamp - self.first_timestamp, 3)

        top_conversations = [
            {"src": src, "dst": dst, "packets": count}
            for (src, dst), count in self.conversation_counts.most_common(10)
        ]

        top_talkers = [
            {"ip": ip, "packets": count, "bytes": self.src_ip_bytes[ip]}
            for ip, count in self.src_ip_counts.most_common(10)
        ]

        top_ports = [
            {"port": _label_port(port), "count": count}
            for port, count in self.dst_port_counts.most_common(10)
        ]

        top_dns = [
            {"domain": domain, "count": count}
            for domain, count in self.dns_queries.most_common(10)
        ]

        return {
            "filepath": self.filepath,
            "total_packets": self.total_packets,
            "total_bytes": self.total_bytes,
            "duration_seconds": duration,
            "protocol_counts": dict(self.protocol_counts),
            "top_talkers": top_talkers,
            "top_conversations": top_conversations,
            "top_ports": top_ports,
            "top_dns_queries": top_dns,
            "warnings": self.warnings,
        }
