"""
core/auth.py
-------------------------------------------------------------------
DackNet-Ops PCAP Analyzer — Authentication Module
-------------------------------------------------------------------
Handles the login gate that runs before the main application opens.

WHY WE HASH THE PASSWORD INSTEAD OF STORING IT AS PLAIN TEXT:
    Storing "dacknet@4631" directly in the source code means anyone
    who opens this .py file on GitHub can instantly read it. Instead,
    we store the SHA-256 *hash* of the password. When the user types
    a password into the login box, we hash what they typed and
    compare the two hashes. This way the real password is never
    visible in the source code, even though the check still works.

    This is a *basic* protection (good enough for a personal/local
    tool) — it is NOT the same as production-grade authentication.
-------------------------------------------------------------------
"""

import hashlib


# This is the SHA-256 hash of "dacknet@4631".
# It was generated once with:
#   hashlib.sha256("dacknet@4631".encode()).hexdigest()
# and pasted here. The plain password itself is never stored.
CORRECT_PASSWORD_HASH = "5e759425e457c985df5c225bd6eff0718e8bc1441dd82814fe5a240e7146a8bb"


def hash_password(plain_text_password: str) -> str:
    """
    Convert a plain-text password into its SHA-256 hash.

    Args:
        plain_text_password: the raw string the user typed in.

    Returns:
        A 64-character hexadecimal hash string.
    """
    # .encode() turns the string into bytes, which hashlib requires.
    return hashlib.sha256(plain_text_password.encode()).hexdigest()


def check_password(attempt: str) -> bool:
    """
    Check whether a login attempt matches the correct password.

    Args:
        attempt: the plain-text password the user just typed.

    Returns:
        True if it matches, False otherwise.
    """
    return hash_password(attempt) == CORRECT_PASSWORD_HASH
