"""
gui/app.py
-------------------------------------------------------------------
DackNet-Ops PCAP Analyzer — Graphical User Interface
-------------------------------------------------------------------
Built with CustomTkinter (a modern-looking skin on top of Tkinter).
This file is only responsible for DRAWING things and reacting to
clicks — all the real packet-parsing work happens in
core/pcap_engine.py, and the login check happens in core/auth.py.

Two screens:
    1. LoginScreen  -> asks for the DackNet-Ops password
    2. DashboardScreen -> lets the user pick a .pcap/.pcapng file,
       runs the analysis, and displays the results
-------------------------------------------------------------------
"""

import os
import threading
import tkinter as tk
from tkinter import filedialog, messagebox

import customtkinter as ctk
from PIL import Image

from core.auth import check_password
from core.pcap_engine import PcapAnalyzer

# ---------------------------------------------------------------
# THEME — DackNet-Ops brand colors (neon green on black)
# ---------------------------------------------------------------
BG_COLOR = "#0a0a0a"
PANEL_COLOR = "#111414"
NEON_GREEN = "#39ff14"
WHITE = "#f2f2f2"
GRAY_TEXT = "#8a8f8a"
WARN_COLOR = "#ff4d4d"

ASSETS_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets")
LOGO_PATH = os.path.join(ASSETS_DIR, "logo.png")

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("green")


def _load_logo(size):
    """Load the DackNet-Ops logo as a CTkImage, or return None if missing."""
    if not os.path.exists(LOGO_PATH):
        return None
    img = Image.open(LOGO_PATH)
    return ctk.CTkImage(light_image=img, dark_image=img, size=size)


class DackNetPcapApp(ctk.CTk):
    """The root application window. Swaps between Login and Dashboard frames."""

    def __init__(self):
        super().__init__()

        self.title("DackNet-Ops :: PCAP Analyzer")
        self.geometry("980x680")
        self.configure(fg_color=BG_COLOR)
        self.minsize(820, 600)

        # Only one of these frames is shown at a time.
        self.login_screen = LoginScreen(self, on_success=self.show_dashboard)
        self.dashboard_screen = None  # built lazily after a successful login

        self.login_screen.pack(fill="both", expand=True)

    def show_dashboard(self):
        """Called by LoginScreen once the correct password is entered."""
        self.login_screen.pack_forget()
        self.dashboard_screen = DashboardScreen(self)
        self.dashboard_screen.pack(fill="both", expand=True)


class LoginScreen(ctk.CTkFrame):
    """The password gate shown when the program first launches."""

    def __init__(self, master, on_success):
        super().__init__(master, fg_color=BG_COLOR)
        self.on_success = on_success

        wrapper = ctk.CTkFrame(self, fg_color=BG_COLOR)
        wrapper.place(relx=0.5, rely=0.5, anchor="center")

        logo_img = _load_logo(size=(190, 190))
        if logo_img:
            ctk.CTkLabel(wrapper, image=logo_img, text="").pack(pady=(0, 12))

        ctk.CTkLabel(
            wrapper, text="DackNet-Ops", font=("Consolas", 30, "bold"),
            text_color=WHITE,
        ).pack()
        ctk.CTkLabel(
            wrapper, text="PCAP ANALYZER", font=("Consolas", 14),
            text_color=NEON_GREEN,
        ).pack(pady=(0, 25))

        self.password_entry = ctk.CTkEntry(
            wrapper, placeholder_text="Enter access password", show="•",
            width=280, height=38, font=("Consolas", 13),
        )
        self.password_entry.pack(pady=(0, 12))
        self.password_entry.bind("<Return>", lambda e: self._attempt_login())

        self.error_label = ctk.CTkLabel(wrapper, text="", text_color=WARN_COLOR)
        self.error_label.pack(pady=(0, 6))

        ctk.CTkButton(
            wrapper, text="UNLOCK", command=self._attempt_login,
            fg_color=NEON_GREEN, hover_color="#2ecc0f", text_color="#000000",
            font=("Consolas", 13, "bold"), width=280, height=38,
        ).pack()

        self.password_entry.focus()

    def _attempt_login(self):
        attempt = self.password_entry.get()
        if check_password(attempt):
            self.on_success()
        else:
            self.error_label.configure(text="Access denied — incorrect password.")
            self.password_entry.delete(0, "end")


class DashboardScreen(ctk.CTkFrame):
    """Main working screen: upload a capture file, run analysis, view results."""

    def __init__(self, master):
        super().__init__(master, fg_color=BG_COLOR)
        self.report = None

        # ---- Header bar ----
        header = ctk.CTkFrame(self, fg_color=PANEL_COLOR, height=70, corner_radius=0)
        header.pack(fill="x", side="top")
        header.pack_propagate(False)

        logo_img = _load_logo(size=(42, 42))
        if logo_img:
            ctk.CTkLabel(header, image=logo_img, text="").pack(side="left", padx=(20, 10))
        ctk.CTkLabel(
            header, text="DackNet-Ops  |  PCAP Analyzer",
            font=("Consolas", 17, "bold"), text_color=WHITE,
        ).pack(side="left")

        self.upload_button = ctk.CTkButton(
            header, text="Upload Capture File", command=self._choose_file,
            fg_color=NEON_GREEN, hover_color="#2ecc0f", text_color="#000000",
            font=("Consolas", 12, "bold"), width=180,
        )
        self.upload_button.pack(side="right", padx=20)

        # ---- Status / progress line ----
        self.status_label = ctk.CTkLabel(
            self, text="No file loaded yet. Click 'Upload Capture File' to begin.",
            text_color=GRAY_TEXT, font=("Consolas", 12),
        )
        self.status_label.pack(anchor="w", padx=20, pady=(12, 4))

        self.progress_bar = ctk.CTkProgressBar(self, progress_color=NEON_GREEN)
        self.progress_bar.set(0)
        self.progress_bar.pack(fill="x", padx=20, pady=(0, 10))

        # ---- Results area (scrollable text) ----
        self.results_box = ctk.CTkTextbox(
            self, fg_color=PANEL_COLOR, text_color=WHITE,
            font=("Consolas", 12), wrap="word",
        )
        self.results_box.pack(fill="both", expand=True, padx=20, pady=(0, 20))
        self.results_box.insert(
            "0.0",
            "Results will appear here once a capture file is analyzed.\n\n"
            "Supported formats: .pcap, .pcapng (anything Wireshark can save).",
        )
        self.results_box.configure(state="disabled")

    # -----------------------------------------------------------
    def _choose_file(self):
        filepath = filedialog.askopenfilename(
            title="Select a Wireshark capture file",
            filetypes=[("Packet captures", "*.pcap *.pcapng"), ("All files", "*.*")],
        )
        if not filepath:
            return

        self.upload_button.configure(state="disabled")
        self.status_label.configure(text=f"Analyzing: {os.path.basename(filepath)} ...")
        self.progress_bar.set(0)

        # Run the (potentially slow) parsing on a background thread so the
        # window doesn't freeze up while a large capture is processed.
        thread = threading.Thread(target=self._run_analysis, args=(filepath,), daemon=True)
        thread.start()

    def _run_analysis(self, filepath):
        try:
            analyzer = PcapAnalyzer(filepath)
            report = analyzer.analyze(progress_callback=self._on_progress)
            self.report = report
            self.after(0, lambda: self._display_report(report))
        except Exception as exc:
            self.after(0, lambda: self._show_error(str(exc)))

    def _on_progress(self, packets_done):
        # Scapy doesn't tell us the total packet count up front, so this
        # progress bar just pulses to show activity rather than a true %.
        self.after(0, lambda: self.status_label.configure(
            text=f"Analyzing... {packets_done} packets processed so far"
        ))

    def _show_error(self, message):
        self.upload_button.configure(state="normal")
        self.status_label.configure(text="Analysis failed.", text_color=WARN_COLOR)
        messagebox.showerror("DackNet-Ops PCAP Analyzer", f"Could not analyze file:\n{message}")

    def _display_report(self, report):
        self.upload_button.configure(state="normal")
        self.progress_bar.set(1)
        self.status_label.configure(
            text=f"Done — {report['total_packets']} packets analyzed.",
            text_color=NEON_GREEN,
        )

        lines = []
        lines.append("=" * 60)
        lines.append(" DACKNET-OPS PCAP ANALYSIS REPORT")
        lines.append("=" * 60)
        lines.append(f"File: {os.path.basename(report['filepath'])}")
        lines.append(f"Total packets: {report['total_packets']}")
        lines.append(f"Total size: {report['total_bytes']:,} bytes")
        if report["duration_seconds"] is not None:
            lines.append(f"Capture duration: {report['duration_seconds']} seconds")
        lines.append("")

        lines.append("-- Protocol Breakdown --")
        for proto, count in sorted(report["protocol_counts"].items(), key=lambda x: -x[1]):
            lines.append(f"  {proto:<8} {count}")
        lines.append("")

        lines.append("-- Top Talkers (by packets sent) --")
        for row in report["top_talkers"]:
            lines.append(f"  {row['ip']:<18} {row['packets']} packets, {row['bytes']:,} bytes")
        lines.append("")

        lines.append("-- Top Conversations (source -> destination) --")
        for row in report["top_conversations"]:
            lines.append(f"  {row['src']:<16} -> {row['dst']:<16} {row['packets']} packets")
        lines.append("")

        lines.append("-- Most-Used Destination Ports --")
        for row in report["top_ports"]:
            lines.append(f"  {row['port']:<18} {row['count']} packets")
        lines.append("")

        if report["top_dns_queries"]:
            lines.append("-- Top DNS Queries --")
            for row in report["top_dns_queries"]:
                lines.append(f"  {row['domain']:<35} {row['count']}")
            lines.append("")

        lines.append("-- Warnings / Points of Interest --")
        if report["warnings"]:
            for warning in report["warnings"]:
                lines.append(f"  [!] {warning}")
        else:
            lines.append("  No obvious red flags spotted by the heuristics.")
        lines.append("")
        lines.append("(These heuristics are basic pattern-matching, not a full IDS.")
        lines.append(" Always confirm anything suspicious by inspecting the capture")
        lines.append(" directly in Wireshark.)")

        self.results_box.configure(state="normal")
        self.results_box.delete("0.0", "end")
        self.results_box.insert("0.0", "\n".join(lines))
        self.results_box.configure(state="disabled")
